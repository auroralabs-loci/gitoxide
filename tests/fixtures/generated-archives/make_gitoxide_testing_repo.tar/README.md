# gitoxide-testing
Example repo to use in gitoxide functional tests

For use with journey tests in: https://github.com/GitoxideLabs/gitoxide

# Summary of commits in this repo and what to test for:

1. `v1`: Just adds `version.txt` and updates the README
2. `v2`: Immediately after v1, adds `new-file-in-v2`, and updates `version.txt` (all tags should have bumped versions of this)
3. `v3`: Has three commits after v2, adds `another-new-file` and a non-executable script `a_script.sh`
4. `v4`: Fixes the script to be executable
5. `v5`: Removes `another-new-file` and moves the changelog to readme
