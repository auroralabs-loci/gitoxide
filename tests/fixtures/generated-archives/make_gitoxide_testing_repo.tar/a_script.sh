#!/bin/sh

echo "This is a script!"
echo "It does things!"

exit 0
